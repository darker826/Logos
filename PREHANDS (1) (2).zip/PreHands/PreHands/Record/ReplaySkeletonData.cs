﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Kinect;


namespace PreHands.Record
{
    public class ReplaySkeletonData
    {
        public List<Joint> Joints { get; private set; }
        public SkeletonPoint Position { get; private set; }
        public SkeletonFrame data;
        public FrameEdges Quality { get; private set; }
        public int TrackingID { get; private set; }
        public SkeletonTrackingState TrackingState { get; private set; }
        public int UserIndex { get; private set; }

        public ReplaySkeletonData(Skeleton data)
        {
            Position = data.Position;
            Quality = data.ClippedEdges;
            TrackingID = data.TrackingId;
            TrackingState = data.TrackingState;
            UserIndex = data.GetHashCode();

            Joints = data.Joints.Cast<Joint>().ToList();
        }

        internal ReplaySkeletonData(BinaryReader reader)
        {
            TrackingState = (SkeletonTrackingState)reader.ReadInt32();
            Position = ReadVector(reader);
            TrackingID = reader.ReadInt32();
            UserIndex = reader.ReadInt32();
            Quality = (FrameEdges)reader.ReadInt32();

            int jointsCount = reader.ReadInt32();
            Joints = new List<Joint>();

            for (int index = 0; index < jointsCount; index++)
            {
                Joint joint = new Joint
                {
                    TrackingState = (JointTrackingState)reader.ReadInt32(),
                    Position = ReadVector(reader)
                };
                Joints.Add(joint);
            }
        }

        public static implicit operator ReplaySkeletonData(Skeleton data)
        {
            return new ReplaySkeletonData(data);
        }

        public static SkeletonPoint ReadVector(BinaryReader reader)
        {
            SkeletonPoint result = new SkeletonPoint
            {
                X = reader.ReadSingle(),
                Y = reader.ReadSingle(),
                Z = reader.ReadSingle()
            };

            return result;
        }
    }
}

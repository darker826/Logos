# PRE HANDS For Effective Presentation
by Logos

#About Team Logos
Project Manager & Framework developer : Park Si Hyeon <br>
PPT Gesture control developer : Lee So Min <br>
Mouse Cursor Control developer : Choi Jae Woung <br>
Remote Function developer : Ham Cho Rom<br>

#About Pre Hands
The Pre Hands is designed to reduce movement time for operate Presentation. <br>
Also, Pre Hands will be improve hand's convenience using motion recognition way.<br> 
There are theories that applied to design, NUI, openCV, openNI and so on. <br>
Moreover, our project is classified and evaluated performance in accordance <br>
with accuracy, implement level, portability, maintainability, convenience.<br>

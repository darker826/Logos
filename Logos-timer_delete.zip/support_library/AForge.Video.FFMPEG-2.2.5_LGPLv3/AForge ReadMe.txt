The folder contains files from Sared and Dev packages of FFMPEG 32-bit and 64-bit builds taken from
http://ffmpeg.zeranoe.com/builds/
Note: few files which are not used by AForge.NET were removed to save space.

Please, refer to README.txt file for details about FFMPEG build.

==============================================
= FFmpeg git-01fcbdf shared LGPL v3 Download =
==============================================
   * Source: 
<http://ffmpeg.zeranoe.com/custom_builds/bnbVwYJXcSeHjk37/ffmpeg-git-01fcbdf.7z>
   * Win32: 
<http://ffmpeg.zeranoe.com/custom_builds/bnbVwYJXcSeHjk37/ffmpeg-git-01fcbdf-win32-shared-lgpl.7z>
   * Win64: 
<http://ffmpeg.zeranoe.com/custom_builds/bnbVwYJXcSeHjk37/ffmpeg-git-01fcbdf-win64-shared-lgpl.7z>